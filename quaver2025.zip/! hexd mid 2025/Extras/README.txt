select every file inside of one of the folder(s) of your choosing, and move them into the original skin folder directory. after that, reload the skin in quaver

make sure to move the skin to C:\Program Files (x86)\Steam\steamapps\common\Quaver\Skins\ (or where ever your install is, this is the default) and delete both the workshop id txt + the preview so it stays that way whenever it updates! <3